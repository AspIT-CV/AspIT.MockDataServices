﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using AspIT.MockDataServices.Models;
using Newtonsoft.Json;

namespace AspIT.MockDataServices
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "PersonJsonService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select PersonJsonService.svc or PersonJsonService.svc.cs at the Solution Explorer and start debugging.
    public class PersonJsonService : IPersonJsonService
    {
        public string GetAllPeople()
        {
            // TODO: Refactor when done testing
            string connectionString = @"Data Source = CVDB3, 1444; Initial Catalog = MockDataDB; Integrated Security = True;";
            string sql = "SELECT FirstName,LastName FROM DanishNames";
            DataSet dataSet = new DataSet();

            // Connect to database
            using(SqlDataAdapter adapter = new SqlDataAdapter(new SqlCommand(sql, new SqlConnection(connectionString))))
            {
                adapter.Fill(dataSet);
            }

            string jsonPeople = string.Empty;
            DataRowCollection rows = dataSet.Tables[0].Rows;
            PersonModel[] people = new PersonModel[rows.Count];

            for(int i = 0; i < rows.Count; i++)
            {
                DataRow row = rows[i];
                people[i] = new PersonModel(row.Field<string>("FirstName"), row.Field<string>("LastName"));
            }

            jsonPeople = JsonConvert.SerializeObject(people);

            // Return json data
            return jsonPeople;
        }
    }
}
