﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AspIT.MockDataServices.Models
{
    public class PersonModel
    {
        #region [Fields]
        /// <summary>
        /// The first name of the person.
        /// </summary>
        protected string firstName;

        /// <summary>
        /// The last name of the person.
        /// </summary>
        protected string lastName;
        #endregion

        #region [Constructors]
        /// <summary>
        /// Initializes a new instance of the <see cref="PersonModel"/> class.
        /// </summary>
        /// <param name="firstName"></param>
        /// <param name="lastName"></param>
        public PersonModel(string firstName, string lastName)
        {
            FirstName = firstName;
            LastName = lastName;
        }
        #endregion

        #region [Properties]
        /// <summary>
        /// Gets or sets the firstname.
        /// </summary>
        public string FirstName { get => firstName; set => firstName = value; }

        /// <summary>
        /// Gets or sets the lastname.
        /// </summary>
        public string LastName { get => lastName; set => lastName = value; }
        #endregion
    }
}